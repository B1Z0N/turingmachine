"""GUI interface to the TuringMachine class"""

